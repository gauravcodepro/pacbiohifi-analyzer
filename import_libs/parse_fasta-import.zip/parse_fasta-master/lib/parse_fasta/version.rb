module ParseFasta
  VERSION = "2.5.2"
end
