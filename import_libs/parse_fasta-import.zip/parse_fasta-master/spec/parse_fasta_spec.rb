require 'spec_helper'

describe ParseFasta do
  it 'has a version number' do
    expect(ParseFasta::VERSION).not_to be nil
  end
end
